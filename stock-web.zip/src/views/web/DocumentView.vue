<template>
  <div class="app-container">
    <navcomponent />
    <div class="main-content">
      <div class="section center" style="max-width: 1400px;">
        <h1 class="gold-text" style="font-size:2.8rem;font-weight:900;letter-spacing:2px;margin-bottom:24px;">
          Documents
        </h1>
        <div style="color:#b0c4e6;font-size:1.2rem;margin-bottom:40px;">
          Access exclusive trading documents and resources
        </div>
      </div>

      <!-- Documents -->
      <div class="section">
        <div id="documents-container">
          <div class="card mb-24" style="position:relative;" v-for="value in documentslist" :key="value.id">
            <div v-if="!value.ispublic" class="vip-badge" style="position:absolute;top:12px;right:12px;background:#FFD700;color:#181F2A;padding:4px 12px;border-radius:12px;font-weight:900;font-size:0.85rem;box-shadow:0 4px 16px #FFD70077;">
              VIP
            </div>
            <div style="display:flex;align-items:center;gap:24px;">
              <span class="avatar-glow" style="width:64px;height:64px;display:inline-flex;align-items:center;justify-content:center;font-size:2.5rem;background:#232b3e;margin-right:8px;">
                <svg viewBox="64 64 896 896" focusable="false" data-icon="file-text" width="1em" height="1em" fill="currentColor" aria-hidden="true">
                  <path d="M534 352V136H196c-17.7 0-32 14.3-32 32v688c0 17.7 14.3 32 32 32h632c17.7 0 32-14.3 32-32V352H534zm-64 0H264V200h206v152zm-80 120h160c4.4 0 8 3.6 8 8v48c0 4.4-3.6 8-8 8H390c-4.4 0-8-3.6-8-8v-48c0-4.4 3.6-8 8-8zm0 120h160c4.4 0 8 3.6 8 8v48c0 4.4-3.6 8-8 8H390c-4.4 0-8-3.6-8-8v-48c0-4.4 3.6-8 8-8z"></path>
                </svg>
              </span>
              <div style="flex:1;">
                <h4 style="color:#fff;margin-bottom:12px;">{{ value.title }}</h4>
                <div style="color:#b0c4e6;margin-bottom:16px;">{{ value.description }}</div>
                <div style="display:flex;align-items:center;gap:16px;color:#b0c4e6;font-size:0.9rem;">
                  <span>Last Updated: {{ value.last_update }}</span>
                </div>
                <div style="margin-top:16px;display:flex;gap:16px;">
                  <a :href="value.file_url" download="" target="_blank" style="color:#FFD700;text-decoration:none;display:inline-flex;align-items:center;gap:8px;">
                    <svg viewBox="64 64 896 896" focusable="false" data-icon="download" width="1em" height="1em" fill="currentColor" aria-hidden="true">
                      <path d="M505.7 661a8 8 0 0012.6 0l112-141.7c4.1-5.2.4-12.9-6.3-12.9h-74.1V168c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v338.3H400c-6.7 0-10.4 7.7-6.3 12.9l112 141.8z"></path>
                      <path d="M878 626h-60c-4.4 0-8 3.6-8 8v154H214V634c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v198c0 17.7 14.3 32 32 32h684c17.7 0 32-14.3 32-32V634c0-4.4-3.6-8-8-8z"></path>
                    </svg>
                    Download
                  </a>
                  <a :href="value.file_url" target="_blank" class="styled-button" style="padding:4px 18px;font-size:1rem;">Preview</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import navcomponent from '../component/nav/nav.vue';
import { getdocuments } from '../../api/module/web/index';
import { useUserStore } from '@/store';

const userStore = useUserStore();
let documentslist = ref({});

onMounted(() => {
  
  getVipDashboardData();
});

const getVipDashboardData = async () => {
  const res = await getdocuments(null);
  if (res.success) {
    documentslist.value = res.data;
   
  }
};
</script>

<style scoped>
/* 复用原有样式 */
.main-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 48px 32px 80px 32px;
}

@media (max-width: 900px) { .main-content { padding: 24px 8px 40px 8px; } }
.app-container {
  background-color: #1a1a2e;
  min-height: 100vh;
  width: 100%;
}
.section {
  background: rgba(24, 31, 42, 0.98);
  border-radius: 28px;
  box-shadow: 0 12px 48px 0 #181F2A55, 0 2px 24px #FFD70022;
  margin-bottom: 48px;
  padding: 48px 36px;
  border: 1.5px solid rgba(255,255,255,0.08);
  position: relative;
}

.gold-text {
  color: #FFD700;
  font-weight: 900;
  letter-spacing: 1px;
}

.card {
  background: linear-gradient(135deg, #232B3E 60%, #222a3a 100%);
  border-radius: 22px;
  box-shadow: 0 8px 32px #181F2A33, 0 0 0 2px #FFD70022;
  border: 1.5px solid rgba(255, 255, 255, 0.10);
  color: #fff;
  padding: 36px 28px;
  margin-bottom: 28px;
  transition: all 0.3s cubic-bezier(.4,2,.6,1);
}

.card:hover {
  box-shadow: 0 16px 64px 0 #FFD70044, 0 0 0 3px #FFD700;
  border-color: #FFD700;
  transform: translateY(-6px) scale(1.03);
}

.styled-button, .ant-btn-primary {
  background: linear-gradient(90deg, #FFD700 0%, #FFB300 100%) !important;
  color: #181F2A !important;
  border: none !important;
  font-weight: 900;
  border-radius: 16px !important;
  box-shadow: 0 6px 24px #FFD70044;
  transition: all 0.3s cubic-bezier(.4,2,.6,1);
  height: 48px;
  padding: 0 32px;
  font-size: 1.15rem;
}

.styled-button:hover, .ant-btn-primary:hover {
  background: linear-gradient(90deg, #FFE066 0%, #FFD700 100%) !important;
  color: #181F2A !important;
  box-shadow: 0 12px 36px #FFD70077;
  transform: translateY(-3px) scale(1.04);
}

.avatar-glow, .ant-avatar {
  border: 2.5px solid #FFD700 !important;
  box-shadow: 0 0 24px #FFD70099, 0 0 0 6px #FFD70022;
  background: #232b3e !important;
}

.mb-24 {
  margin-bottom: 24px;
}

.center {
  text-align: center;
}

@media (max-width: 600px) {
  html, body {
    background: linear-gradient(135deg, #232B3E 60%, #222a3a 100%) !important;
    padding: 0 !important;
    margin: 0 !important;
    width: 100vw !important;
    min-width: 0 !important;
    max-width: 100vw !important;
    overflow-x: hidden !important;
  }
  .main-content {
    max-width: 100vw !important;
    width: 100vw !important;
    min-width: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
    left: 0 !important;
    position: relative !important;
    background: none !important;
    box-shadow: none !important;
  }
  .section {
    padding: 8px 0 !important;
    min-height: unset !important;
    margin-top: 0 !important;
    margin-bottom: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: none !important;
    border: none !important;
  }
}
</style>