<template>
  <div class="app-container">
    <navcomponent />
    <div class="main-content">
      <div class="section center" style="max-width: 1400px;">
        <h1 class="gold-text" style="font-size:2.8rem;font-weight:900;letter-spacing:2px;margin-bottom:24px;">
          Video Tutorials
        </h1>
        <div style="color:#b0c4e6;font-size:1.2rem;margin-bottom:40px;">
          Watch exclusive video tutorials to improve your trading skills
        </div>
      </div>

      <!-- Video Courses -->
      <div class="section">
        <div id="videos-container" class="flex-row" style="display:flex;flex-wrap:wrap;gap:24px;">
          <div class="card" style="flex:0 0 calc(33.333% - 16px);min-width:320px;position:relative;" v-for="value in vedioslist" :key="value.id">
            <div v-if="!value.ispublic" class="vip-badge" style="position:absolute;top:12px;right:12px;background:#FFD700;color:#181F2A;padding:4px 12px;border-radius:12px;font-weight:900;font-size:0.85rem;box-shadow:0 4px 16px #FFD70077;">
              VIP
            </div>
            <div style="height:280px;background:#232e4a;border-radius:16px;display:flex;align-items:center;justify-content:center;margin-bottom:24px;">
              <video :src="value.video_url" controls="" style="width:100%;height:280px;border-radius:12px;background:#232e4a;"></video>
            </div>
            <h4 style="color:#fff;margin-bottom:16px;">{{ value.title }}</h4>
            <div style="color:#b0c4e6;margin-bottom:12px;height:140px;overflow-y: auto;">{{ value.description }}</div>
            <div style="color:#b0c4e6;margin-bottom:12px;">Last Updated: {{ value.last_update }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import navcomponent from '../component/nav/nav.vue';
import { getvideos } from '../../api/module/web/index';
import { useUserStore } from '@/store';

const userStore = useUserStore();
let vedioslist = ref({});

onMounted(() => {
  // try {
  //   Vipdata.value = userStore.VipData;
  // } catch {}
  getVipDashboardData();
});

const getVipDashboardData = async () => {
  const res = await getvideos(null);
  if (res.success) {
    vedioslist.value = res.data;
    // userStore.VipData = res.data;
  }
};
</script>

<style scoped>
/* 复用原有样式 */
.main-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 48px 32px 80px 32px;
}
.app-container {
  background-color: #1a1a2e;
  min-height: 100vh;
  width: 100%;
}

@media (max-width: 900px) { .main-content { padding: 24px 8px 40px 8px; } }

.section {
  background: rgba(24, 31, 42, 0.98);
  border-radius: 28px;
  box-shadow: 0 12px 48px 0 #181F2A55, 0 2px 24px #FFD70022;
  margin-bottom: 48px;
  padding: 48px 36px;
  border: 1.5px solid rgba(255,255,255,0.08);
  position: relative;
}

.gold-text {
  color: #FFD700;
  font-weight: 900;
  letter-spacing: 1px;
}

.card {
  background: linear-gradient(135deg, #232B3E 60%, #222a3a 100%);
  border-radius: 22px;
  box-shadow: 0 8px 32px #181F2A33, 0 0 0 2px #FFD70022;
  border: 1.5px solid rgba(255, 255, 255, 0.10);
  color: #fff;
  padding: 36px 28px;
  margin-bottom: 28px;
  transition: all 0.3s cubic-bezier(.4,2,.6,1);
}

.card:hover {
  box-shadow: 0 16px 64px 0 #FFD70044, 0 0 0 3px #FFD700;
  border-color: #FFD700;
  transform: translateY(-6px) scale(1.03);
}

.flex-row {
  display: flex;
  flex-wrap: wrap;
  gap: 40px;
}

.center {
  text-align: center;
}

@media (max-width: 600px) {
  html, body {
    background: linear-gradient(135deg, #232B3E 60%, #222a3a 100%) !important;
    padding: 0 !important;
    margin: 0 !important;
    width: 100vw !important;
    min-width: 0 !important;
    max-width: 100vw !important;
    overflow-x: hidden !important;
  }
  .main-content {
    max-width: 100vw !important;
    width: 100vw !important;
    min-width: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
    left: 0 !important;
    position: relative !important;
    background: none !important;
    box-shadow: none !important;
  }
  .section {
    padding: 8px 0 !important;
    min-height: unset !important;
    margin-top: 0 !important;
    margin-bottom: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: none !important;
    border: none !important;
  }
}
</style>