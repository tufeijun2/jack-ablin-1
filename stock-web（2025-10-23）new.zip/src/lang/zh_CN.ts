export default {
    hello: "你好"
}